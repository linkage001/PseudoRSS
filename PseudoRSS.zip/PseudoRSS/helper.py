from bs4 import BeautifulSoup
import requests
from txt_author import Author as TXTAuthor
from clock import Clock
import pandas as pd
from flask_thread import FlaskInThread


url_list = TXTAuthor.read_list_from_file('url_list.txt')
word_list = TXTAuthor.read_list_from_file('word_list.txt')
bs = TXTAuthor.read_str_from_file('bootstrap.txt')

txt_author = TXTAuthor()
clock = Clock()
df = pd.DataFrame({}, columns=['ID', 'Website', 'Word',  'Datetime', 'Link'])
flask = FlaskInThread(bs)

def format_site_as_title(site):
    title = site.replace('https://www.', '').replace('http://www.', '').replace('http://', '').replace('https://', '')
    if "''" in site or '""' in site:
        site = clean_misread_literal(site)
    return f'<a href=/?website={site.lower()}>{title.title()}</a>'


def insert_newlines(string, every=64):
    lines = []
    for i in range(0, len(string), every):
        lines.append(string[i:i+every])
    return '<br>'.join(lines)

def limit_text_lenght(string, limit=78):
    if len(string) > limit:
        string = string[0:limit] + '...'
    return string

def format_link_field(text, url, href):
    if href[0] == '/':
        href = url + href[1:]
    # text = insert_newlines(text) + '<br>'
    text = limit_text_lenght(text)
    link = f'<a href="{href}">{text}</a>'
    return link\
        .replace('\t', '')\
        .replace(',', '%COMMA%')

def clean_misread_literal(v):
        while v.find('\"\"') > -1:
            v = v.replace('\"\"', '\"')
        while v.find('\'\'') > -1:
            v = v.replace("\'\'", "\'")
        return v

def get_id_from_link(link):
    id = 0
    link = str(link)
    for char in list(link):
        id += ord(char)
    return id


# Returns a list of found words in the target URL
def find_words_in_url(words, url):
    headers = {'x-api-key': '09ba90f6-dcd0-42c0-8c13-5baa6f2377d0'}
    resp_text = requests.get(url, headers=headers).content.decode('utf-8')
    resp_lower = resp_text.lower()
    if len(resp_text) < 500:
        print(f'{url} not returning news')
    found_words = []
    for word in words:
        result = resp_lower.find(word.lower()) > -1
        if result:
            found_words.append(word)

    return resp_text, found_words

def load_links_from_urls():
    global df
    for url in url_list:
        r, w = find_words_in_url(word_list, url)

        soup = BeautifulSoup(r, 'html.parser')
        links = soup.find_all('a')

        for link in links:
            for word in w:
                if word.lower() in str(link.text).lower() and 'src=' not in str(link):
                    l = {
                        'ID': get_id_from_link(link),
                        'Website': format_site_as_title(url),
                        'Word': f'<a href=/?word={word.lower()}>{word.title()}</a>',
                        'Datetime': clock.get_datetime_string(),
                        'Link': format_link_field(text=link.text, url=url, href=link.get('href')),
                    }
                    if l['ID'] not in df.ID.values:
                        new_df = pd.DataFrame([l])
                        df = df.append(new_df)
                        del_old_links_from_df()


def del_old_links_from_df():
    global df
    global flask
    try:
        df = df[(df['Datetime'] > clock.get_datetime_minus_hours_string(48)) & (df['Datetime'] <
                                                                                clock.get_datetime_string())]
    except Exception as e:
        print("new_df = df[(df['Datetime'] ERROR")
        print(e)
    flask.df = df