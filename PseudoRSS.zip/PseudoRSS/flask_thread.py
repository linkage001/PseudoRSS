from flask import Flask, request
import threading, os
from flask import render_template
from clock import Clock

class FlaskInThread:

    df = None

    buttons = """
    <style>
        div {text-align: center;}
    </style>
    <div><button class="btn btn-primary btn-lg" onclick="window.location.href='/quit/';">
      QUIT
    </button></div>"""

    def make_index(self, coloumn, filter):
        print(f'Retuning filtered html: {filter}')
        filter = str(filter)
        if self.df is None or self.df.size < 1:
            return render_template("loading.html")
        df = self.df
        clock = Clock()
        new_df = df[(df['Datetime'] > clock.get_datetime_minus_hours_string(48)) & (df['Datetime'] <
                                                                                    clock.get_datetime_string())]
        new_df = new_df.filter(items=['Website', 'Word', 'Link'])
        new_df = new_df[new_df[coloumn].str.contains(filter)]
        html_table = new_df.to_html(classes=["table-bordered", "table-striped", "table-hover", "table-dark"])
        html_table = html_table\
            .replace('&lt;', '<')\
            .replace('&gt;', '>')\
            .replace('\\n', '') \
            .replace('&lt;', '<')\
            .replace('&gt;', '>')\
            .replace('\\n', '')\
            .replace('%COMMA%', ',')
        return self.bs + self.buttons + html_table

    def __init__(self, bs):
        app = Flask(__name__)
        self.bs = bs
        self.main = 'Loading initial data...'

        @app.route("/", methods=['POST', 'GET'])
        def table():

            if request.method == 'POST':
                pass
            else:
                word = str(request.args.get('word'))
                website = str(request.args.get('website'))
                word_is_none = word.find('None') > -1
                if not word_is_none:
                    return self.make_index('Word', word)
                website_is_none = website.find('None') > -1
                if not website_is_none:
                    return self.make_index('Website', website)

            return self.make_index('Word', '')

        @app.route("/quit/", methods=['POST', 'GET'])
        def quit():
            os._exit(1)
            return "Bye"

        threading.Thread(target=app.run).start()