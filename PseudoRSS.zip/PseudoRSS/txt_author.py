from collections import Counter
import operator

class Author:


    @classmethod
    def count_words_from_file(cls, txt):
        l = []
        with open(txt, 'r', encoding="utf8", errors='ignore') as f:
            text = f.read()
            counted = sorted(Counter(text.split()).items(),
                             key=operator.itemgetter(1), reverse=True)
            return counted

    @classmethod
    def read_list_from_file(cls, txt):
        l = []
        with open(txt, 'r', encoding="utf8", errors='ignore') as f:
            lines = f.read().split('\n')
            for i, line in enumerate(lines):
                if i == len(lines) -1:
                    continue
                l.append(line)
            return l

    @classmethod
    def read_str_from_file(cls, txt):
        l = []
        with open(txt, 'r', encoding="utf8", errors='ignore') as f:
            text = f.read()
            return text

    @classmethod
    def write_list_to_file(cls, file, lines):
        l = list(map(str, lines))
        with open(file, 'w+') as f:
            for line in l:
                f.write(line + '\n')

    @classmethod
    def write_string_to_file(cls, file, string):
        with open(file, 'w+') as f:
            f.write(string)


