# install with:
# pip install -r requirements.txt

import time
from helper import *

while True:
    try:
        load_links_from_urls()
    except Exception as e:
        print(e)
    time.sleep(300)

