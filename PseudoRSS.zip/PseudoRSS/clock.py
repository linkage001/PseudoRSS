from datetime import datetime, timedelta

class Clock:

    alarm = ''
    lap = []

    def get_datetime_string(self):
        now = datetime.now()
        return str(now)

    def get_datetime_minus_hours_string(self, hours):
        now = datetime.now()
        d = now - timedelta(hours=hours)
        return str(d)

    def get_date_string(self):
        s = self.get_datetime_string()
        return s[:10]

    def get_time_string(self):
        s = self.get_datetime_string()
        return s[11:]

    def set_lap(self):
        self.lap.append(self.get_time_string())